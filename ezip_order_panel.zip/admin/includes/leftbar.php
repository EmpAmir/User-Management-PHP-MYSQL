	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">

			<li class="ts-label">Main</li>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

			<li><a href="userlist.php"><i class="fa fa-users"></i> Userlist</a>
			</li>
			<li><a href="admin_orders_list.php"><i class="fa fa-users"></i> Orderlist</a>
			<li><a href="admin_sell_list.php"><i class="fa fa-users"></i> Sell List</a>
			</li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
			<li><a href="deleteduser.php"><i class="fa fa-user-times"></i> &nbsp;Deleted Users</a>
			</li>
			<li><a href="download.php"><i class="fa fa-download"></i> &nbsp;Download Users-List</a>
			</li>
		</ul>
		<p class="text-center" style="color:#ffffff; margin-top: 100px;">© Ajay</p>
	</nav>